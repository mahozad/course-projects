import java.util.*;

public class Main {

    private int degree;
    private int[] coefficients;
    private double roots[];

    public void getExpression() {
        getDegree();
        getCoefficients();
        roots();
    }

    public void roots() {
    }

    public void getDegree() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the degree of your polynomial:");
        try {
            degree = scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("NavN\n");
            getDegree();
        }
        while (degree < 0 || degree > 10) {
            System.out.println("Degree of polynomial could be between 0-10. Enter a valid " +
                    "degree:");
            try {
                degree = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("NavN\n");
                getDegree();
            }
        }
    }

    public void getCoefficients() {
        Scanner scanner = new Scanner(System.in);
        coefficients = new int[degree];
        roots = new double[degree];
        for (int i = 0; i < degree; i++) {
            System.out.println("\nEnter the coefficient of the " + i + "th term:");
            try {
                coefficients[i] = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("NavN");
                System.exit(1);
            }
        }
    }
}
