public class Application {

    public static void main(String args[]) {
        try {
            Maze maze = new Maze();
            maze.start();
        } catch (java.io.IOException e) {
            e.getMessage();
        }
    }
}
