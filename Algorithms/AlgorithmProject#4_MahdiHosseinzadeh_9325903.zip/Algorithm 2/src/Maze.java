import java.io.*;

public class Maze {

    private double jobs[][] = new double[30][30];
    private String mainString;
    private final int N = 99;

    public void start() throws IOException {
        mainString = new RandomAccessFile("TestSample.txt", "r").readUTF();
        initializeArray();
        prcsbck(0, 0);
    }

    public void initializeArray() throws IOException {
        mainString = mainString.replaceAll("\\t", "\n");
        mainString = mainString.replaceAll("\\r\\n", "\n");
        RandomAccessFile file = new RandomAccessFile("cleanfile.txt", "rw");
        mainString = "0.".concat(mainString);
        file.writeChars(mainString);
        mainString = removeNullChars(mainString);
        file.seek(0);
        for (int i = 0; i < 30; i++) {
            for (int j = 0; j < 30; j++) {
                jobs[i][j] = Double.parseDouble(file.readLine());
            }
        }
    }

    public String removeNullChars(String string) {
        String temp = "";
        char[] chars = string.toCharArray();
        for (char aChar : chars) {
            if (aChar != '\u0000') {
                temp += aChar;
            }
        }
        return temp;
    }

    public void prcsbck(int i, int j) {
        jobs[i][j] = 'v';
        if (i == N && j == N) {
            printPath();
        } else {
            if (j + 1 < N && jobs[i][j + 1] != '1') {
                prcsbck(i, j + 1);
            }
            jobs[i][j + 1] = 'i';
            if (i + 1 < N && jobs[i + 1][j] != '1') {
                prcsbck(i + 1, j);
            }
        }
    }

    public void printPath() {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (jobs[i][j] == 'v') {
                    System.out.printf("[%d . %d]", i, j);
                }
            }
        }
    }
}
