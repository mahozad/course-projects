import java.io.*;

public class Maze {

    private char maze[][] = new char[100][100];
    private String mainString;
    private final int N = 99;

    public void start() throws IOException {
        mainString = new RandomAccessFile("SampleMaze.txt", "rw").readUTF();
        initializeArray();
        move(0, 0);
    }

    public void initializeArray() {
        mainString = mainString.replaceAll("\\t", "");
        mainString = mainString.replaceAll("\\r\\n", "");
        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < 100; j++) {
                maze[i][j] = mainString.charAt(j);
            }
        }
    }

    public void move(int i, int j) {
        maze[i][j] = 'v';
        if (i == N && j == N) {
            printPath();
        } else {
            if (j + 1 < N && maze[i][j + 1] != '1') {
                move(i, j + 1);
            }
            maze[i][j + 1] = 'i';
            if (i + 1 < N && maze[i + 1][j] != '1') {
                move(i + 1, j);
            }
        }
    }

    public void printPath() {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (maze[i][j] == 'v') {
                    System.out.printf("[%d . %d]", i, j);
                }
            }
        }
    }
}
