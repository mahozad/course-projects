import pandas
import matplotlib.pyplot as plt

def draw_boxplot(table):
	data = table.iloc[:,[1, 5]] # selecet columns 1 and 5 (SepalLengthCm and Species)
	data.boxplot(column='SepalLengthCm', by='Species')
	plt.show()
	
def count_species(table):
	species = table.groupby(['Species']).size()
	print('\n', species)
	
def mean(table):
	sl_mean = table['SepalLengthCm'].mean()
	sw_mean = table['SepalWidthCm'].mean()
	pl_mean = table['PetalLengthCm'].mean()
	pw_mean = table['PetalWidthCm'].mean()
	print('\nMeans: ', sl_mean, '\t', sw_mean, '\t', pl_mean, '\t', pw_mean)

def mode(table):
	sl_mode = table['SepalLengthCm'].mode().values
	sw_mode = table['SepalWidthCm'].mode().values
	pl_mode = table['PetalLengthCm'].mode().values
	pw_mode = table['PetalWidthCm'].mode().values
	print('\nModes: ', sl_mode, '\t', sw_mode, '\t', pl_mode, '\t', pw_mode)
	
def median(table):
	sl_median = table['SepalLengthCm'].median()
	sw_median = table['SepalWidthCm'].median()
	pl_median = table['PetalLengthCm'].median()
	pw_median = table['PetalWidthCm'].median()
	print('\nMedians: ', sl_median, '\t', sw_median, '\t', pl_median, '\t', pw_median)
	
table = pandas.read_csv('Iris.csv')

draw_boxplot(table)
count_species(table)
mean(table)
mode(table)
median(table)