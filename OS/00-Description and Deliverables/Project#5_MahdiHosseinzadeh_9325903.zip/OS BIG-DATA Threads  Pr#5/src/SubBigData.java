import java.io.*;
import java.util.concurrent.locks.*;

public class SubBigData implements Runnable {

    private static final ReentrantLock LOCK = new ReentrantLock();
    private static final Object QUEUE = new Object();
    private static int threadsDone = 0;
    private static double average = 0;
    private static String filePath;
    private static int threadsNum;
    private static int flag = 0;
    private static int max;
    private int fileBeg;
    private int fileEnd;

    public SubBigData(int beg, int end) {
        fileBeg = beg;
        fileEnd = end;
    }

    public static void initialize(int initialMax, String path, int num) {
        max = initialMax;
        filePath = path;
        threadsNum = num;
    }

    @Override
    public void run() {
        try {
            RandomAccessFile file = new RandomAccessFile(filePath, "r");
            file.seek(fileBeg * 4);
            int max = file.readInt();
            int num;
            int totalNumbers = fileEnd - fileBeg + 1;
            long sum = 0;
            file.seek(fileBeg * 4);
            for (int i = 0; i < totalNumbers; i++) {
                num = file.readInt();
                sum += num;
                if (num > max) {
                    max = num;
                }
            }
            file.close();
            double subAverage = (double) sum / totalNumbers;
            setMax(max);
            manipulateAverage(subAverage);
            incrementFlag();
        } catch (Exception e) {
            e.getMessage();
        }
    }

    public void manipulateAverage(double subAverage) throws Exception {
        if (subAverage < 1000) {
            long startTime = System.currentTimeMillis();
            synchronized (QUEUE) {
                QUEUE.wait(2000);
            }
            if (System.currentTimeMillis() - startTime <= 2000) {
                LOCK.lock();
                average += subAverage;
                System.out.printf("\nUpdated average: %.2f", average / ++threadsDone);
                LOCK.unlock();
            } else {
                System.out.printf("\n%16s", "Time-out!");
            }
        } else {
            LOCK.lock();
            average += subAverage;
            Thread.sleep(500);
            System.out.printf("\nUpdated average: %.2f", average / ++threadsDone);
            LOCK.unlock();
            synchronized (QUEUE) {
                for (int i = 0; i < 3; i++) {
                    QUEUE.notify();
                }
            }
        }
    }

    public static synchronized void setMax(int subMax) {
        if (subMax > max) {
            max = subMax;
        }
    }

    public static int getMax() {
        return max;
    }

    public static synchronized void incrementFlag() {
        flag++;
        if (flag == threadsNum) {
            synchronized (BigData.class) {
                BigData.class.notify();
            }
        }
    }
}