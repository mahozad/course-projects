import java.io.*;
import java.rmi.*;

public class SubBigDataRun {

    private RandomAccessFile file;
    private double average;
    private int fileBeg;
    private int fileEnd;
    private int max;

    public void run(String args[]) throws Exception {
        ServerInterface bigDataServer = (ServerInterface) Naming.lookup("//localhost/RmiServer");
        file = new RandomAccessFile(args[1], "r");
        setRange(args[0]);
        calculate();
        bigDataServer.setResults(max, average);
    }

    public void setRange(String range) {
        int index = 0;
        while (range.charAt(index) != '-') {
            index++;
        }
        fileBeg = Integer.parseInt(range.substring(0, index));
        fileEnd = Integer.parseInt(range.substring(index + 1));
    }

    public void calculate() throws IOException {
        file.seek(fileBeg * 4 + 4);
        max = file.readInt();
        file.seek(fileBeg * 4 + 4);
        int num;
        long sum = 0;
        int totalNumbers = fileEnd - fileBeg;
        for (int i = 0; i < totalNumbers; i++) {
            num = file.readInt();
            sum += num;
            if (num > max) {
                max = num;
            }
        }
        average = (double) sum / totalNumbers;
    }
}
