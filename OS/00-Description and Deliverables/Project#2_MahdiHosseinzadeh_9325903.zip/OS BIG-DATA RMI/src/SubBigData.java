public class SubBigData {

    public static void main(String args[]) throws Exception {
        SubBigDataRun subBigDataRun = new SubBigDataRun();
        subBigDataRun.run(args);
    }
}
