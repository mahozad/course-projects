import java.io.*;
import java.util.concurrent.locks.*;

public class SubBigData implements Runnable {

    private static final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private static int threadsDone = 0;
    private static double average = 0;
    private static String filePath;
    private static int flag = 0;
    private static int max;
    private long startTime;
    private int fileBeg;
    private int fileEnd;

    public SubBigData(int beg, int end) {
        fileBeg = beg;
        fileEnd = end;
    }

    public static void setMaxAndAddress(int initialMax, String path) {
        max = initialMax;
        filePath = path;
    }

    @Override
    public void run() {
        try {
            RandomAccessFile file = new RandomAccessFile(filePath, "r");
            file.seek(fileBeg * 4);
            int max = file.readInt();
            file.seek(fileBeg * 4);
            long sum = 0;
            int num;
            int totalNumbers = fileEnd - fileBeg + 1;
            for (int i = 0; i < totalNumbers; i++) {
                num = file.readInt();
                sum += num;
                if (num > max) {
                    max = num;
                }
            }
            file.close();
            double average = (double) sum / totalNumbers;
            setMax(max);
            manipulateAverage(average, this);
        } catch (Exception ignored) {
        }
    }

    public static void manipulateAverage(double subAverage, SubBigData thisThread) throws
            Exception {
        if (subAverage < 1000) {
            lock.readLock().lock();
            System.out.printf("\nCurrent average: %.2f", threadsDone == 0 ? average : average /
                    threadsDone);
            lock.readLock().unlock();
        } else {
            thisThread.startTime = System.currentTimeMillis();
            lock.writeLock().lock();
            if (System.currentTimeMillis() - thisThread.startTime > 2000) {
                System.out.printf("\n%16s", "Time-out!");
            } else {
                average += subAverage;
                Thread.sleep(1000);
                System.out.printf("\nUpdated average: %.2f", average / ++threadsDone);
            }
            lock.writeLock().unlock();
        }
        incrementFlag();
    }

    public static synchronized void setMax(int subMax) {
        if (subMax > max) {
            max = subMax;
        }
    }

    public static int getMax() {
        return max;
    }

    public static int getFlag() {
        return flag;
    }

    public static synchronized void incrementFlag() {
        flag++;
    }
}
