import java.util.concurrent.*;
import java.util.*;
import java.io.*;

public class BigData {

    private ExecutorService executor;
    private String fileAddress;
    private int totalNumbers;
    private int initialMax;
    private long startTime;
    private int prcsNum;

    public void bigDataRun() throws IOException, InterruptedException {
        final int ACTIVETHREADS = 20;
        getAndCheckFile();
        getAndCheckNum();
        int ranges[][] = new int[prcsNum][2];
        for (int i = 0, bound = 0; i < prcsNum; i++) {
            ranges[i][0] = bound;
            ranges[i][1] = totalNumbers / prcsNum + bound;
            bound += totalNumbers / prcsNum;
        }
        executor = Executors.newFixedThreadPool(ACTIVETHREADS);
        SubBigData[] subBigData = new SubBigData[prcsNum];
        SubBigData.setAddress(fileAddress);
        startTime = System.currentTimeMillis();
        for (int i = 0; i < prcsNum; i++) {
            subBigData[i] = new SubBigData(ranges[i][0], ranges[i][1], initialMax);
            executor.execute(subBigData[i]);
        }
        printResults();
    }

    public void getAndCheckFile() throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("Enter the input file address:\n");
        fileAddress = scanner.nextLine();
        File file = new File(fileAddress);
        while (!file.exists() || file.isDirectory() || isNotDat(file)) {
            if (!file.exists()) {
                System.out.printf("The file you specified does not exist.");
            } else if (file.isDirectory()) {
                System.out.printf("The address you specified is a directory.");
            } else {
                System.out.printf("This file is not in .dat format.");
            }
            System.out.printf(" Enter a valid file address:\n");
            fileAddress = scanner.nextLine();
            file = new File(fileAddress);
        }
        RandomAccessFile mainFile = new RandomAccessFile(file, "r");
        totalNumbers = mainFile.readInt();
        initialMax = mainFile.readInt();
        mainFile.close();
    }

    public boolean isNotDat(File file) {
        return !file.getName().endsWith(".dat");
    }

    public void getAndCheckNum() {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("Enter number of threads to create:\n");
        try {
            prcsNum = scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("NaN\n");
            getAndCheckNum();
        }
        while (prcsNum < 1) {
            System.out.printf("Number of threads cannot be less than 1. Enter a valid number:\n");
            try {
                prcsNum = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("NaN\n");
                getAndCheckNum();
            }
        }
    }

    public void printResults() throws InterruptedException {
        while (SubBigData.getFlag() < prcsNum) Thread.sleep(1);
        long duration = System.currentTimeMillis() - startTime;
        double average = SubBigData.getSum() / prcsNum;
        System.out.printf("\n%11s %.2f\n%11s %d\n%11s %.2f sec\n\n"
                , "Average:", average, "Maximum:", SubBigData.getMax()
                , "Total time:", (double) duration / 1000);
        executor.shutdown();
    }
}
