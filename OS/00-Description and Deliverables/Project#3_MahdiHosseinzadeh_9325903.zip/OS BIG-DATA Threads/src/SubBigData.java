import java.io.*;

public class SubBigData extends Thread {

    private static double totalSum = 0;
    private static String filePath;
    private RandomAccessFile file;
    private static int flag = 0;
    private static int max;
    private int fileBeg;
    private int fileEnd;

    public SubBigData(int beg, int end, int initialMax) {
        fileBeg = beg;
        fileEnd = end;
        max = initialMax;
    }

    @Override
    public void run() {
        try {
            file = new RandomAccessFile(filePath, "r");
        } catch (FileNotFoundException ignored) {
        }
        try {
            calculate();
        } catch (IOException ignored) {
        }
    }

    public void calculate() throws IOException {
        file.seek(fileBeg * 4 + 4);
        int max = file.readInt();
        file.seek(fileBeg * 4 + 4);
        long sum = 0;
        int num;
        int totalNumbers = fileEnd - fileBeg;
        for (int i = 0; i < totalNumbers; i++) {
            num = file.readInt();
            sum += num;
            if (num > max) {
                max = num;
            }
        }
        double average = (double) sum / totalNumbers;
        setMax(max);
        addSum(average);
        incrementFlag();
    }

    public static void setAddress(String path) {
        filePath = path;
    }

    public static synchronized void addSum(double sum) {
        totalSum += sum;
    }

    public static synchronized void incrementFlag() {
        flag++;
    }

    public static synchronized void setMax(int max) {
        if (max > SubBigData.max) {
            SubBigData.max = max;
        }
    }

    public static int getMax() {
        return max;
    }

    public static double getSum() {
        return totalSum;
    }

    public static synchronized int getFlag() {
        return flag;
    }
}
