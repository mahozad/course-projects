import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Calendar;

/**
 * Created by mohammadchangani on 10/4/17.
 * internet-engineering
 */
public class HelloHttpServer {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = null;
        Socket clientSocket = null;
        PrintWriter out = null;
        BufferedReader in = null;

        try {
            serverSocket = new ServerSocket(9077);
            System.out.println("Waiting for connection.....");

            while (true) {
                clientSocket = serverSocket.accept();
                System.out.println(clientSocket);
                System.out.println("Connection successful");

                out = new PrintWriter(clientSocket.getOutputStream());
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));


                //read request
                while (in.ready()) {
                    final String line = in.readLine();
                    if (line.isEmpty()) {
                        break;
                    }
                }

                final String responseBody = "Hello!\n";
                out.println("HTTP/1.1 200 OK");
                out.println("Date:" + Calendar.getInstance().getTime());
                out.println("Content-Type: text/html");
                out.println("Content-Length: " + responseBody.length());
                out.println();
                out.print(responseBody);

                out.close();
            }

        } catch (Exception e) {
            e.printStackTrace(System.err);
        } finally {
            if (out != null) {
                out.close();
            }
            if (in != null) {
                in.close();
            }
            if (clientSocket != null) {
                clientSocket.close();
            }
            if (serverSocket != null) {
                serverSocket.close();
            }
        }
    }
}
