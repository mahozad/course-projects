import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Calendar;

/**
 * Created by mohammadchangani on 10/4/17.
 * internet-engineering
 */
public class FileHttpServer {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = null;
        Socket clientSocket = null;
        BufferedOutputStream out = null;
        BufferedReader in = null;

        try {
            serverSocket = new ServerSocket(9077);

            while (true) {

                System.out.println("Waiting for connection.....");

                clientSocket = serverSocket.accept();
                System.out.println(clientSocket);
                System.out.println("Connection successful");

                out = new BufferedOutputStream(clientSocket.getOutputStream());
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));


                handleRequest(in, out);

                clientSocket.close();
            }

        } catch (Exception e) {
            e.printStackTrace(System.err);
        } finally {
            if (out != null) {
                out.close();
            }
            if (in != null) {
                in.close();
            }
            if (clientSocket != null) {
                clientSocket.close();
            }
            if (serverSocket != null) {
                serverSocket.close();
            }
        }
    }

    private static void handleRequest(BufferedReader in, BufferedOutputStream out) throws Exception {
        String line = in.readLine();
        final String method;
        final String path;

        try {
            final String[] split = line.split(" ");
            method = split[0];
            path = split[1];
        } catch (Exception e) {
            writeResponse(out, StatusCode.BAD_REQUEST);
            return;
        }

        if (!method.equals("GET")) {
            writeResponse(out, StatusCode.NOT_IMPLEMENT);
            return;
        }

        while (in.ready()) {
            line = in.readLine();
            if (line.isEmpty()) {
                break;
            }
        }

        final File file = new File("/root/http-server/docs/" + path);
        if (!file.exists()) {
            writeResponse(out, StatusCode.NOT_FOUND);
            return;
        }
        final String contentType = findContentType(path);

        try (final InputStream payloadFile
                     = new FileInputStream(file)) {

            writeResponse(out, StatusCode.OK,
                    payloadFile, contentType, file.length());
        }
    }

    private static void writeResponse(BufferedOutputStream out, StatusCode statusCode) throws Exception {
        final String response = statusCode.toString();

        writeResponse(out, statusCode, new ByteArrayInputStream(response.getBytes()),
                "text/html", response.length());
    }

    private static void writeResponse(BufferedOutputStream out, StatusCode statusCode, InputStream payloadFile,
                                      String contentType, long contentLength) throws Exception {
        final StringBuilder response = new StringBuilder();
        response.append("HTTP/1.1 ").append(statusCode.code).append(" ").append(statusCode.name).append("\n");
        response.append("Date:").append(Calendar.getInstance().getTime()).append("\n");
        response.append("Content-Type: ").append(contentType).append("\n");
        response.append("Content-Length: ").append(contentLength).append("\n");
        response.append("\n");

        out.write(response.toString().getBytes());

        while (true) {
            final int b = payloadFile.read();
            if (b == -1) {
                break;
            }
            out.write(b);
        }

        out.close();
    }

    private static String findContentType(String path) {
        if (path.endsWith(".html") || path.endsWith(".htm")) {
            return "text/html";
        }
        if (path.endsWith(".png")) {
            return "image/png";
        }
        if (path.endsWith(".jpg") || path.endsWith(".jpeg")) {
            return "image/jpeg";
        }
        return "application/octet-stream";
    }

    private enum StatusCode {
        OK(200, "OK"),
        BAD_REQUEST(401, "Bad Request"),
        NOT_FOUND(404, "Not Found"),
        NOT_IMPLEMENT(501, "Not Implement");

        private final int code;
        private final String name;

        StatusCode(int code, String name) {
            this.code = code;
            this.name = name;
        }

        @Override
        public String toString() {
            return code + " - " + name;
        }
    }
}
