//@RunWith(JUnit4.class)

import ir.example.web.config.AppConfig;
import ir.example.web.model.entity.UserEntity;
import ir.example.web.service.PollService;
import ir.example.web.service.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {AppConfig.class})
@WebAppConfiguration
public class InitDataTest {

    @Autowired
    private UserService userService;

    @Autowired
    private PollService pollService;

    @Test
    public void addUser() {
        UserEntity user1 = new UserEntity();
        user1.setName("Ali");
        user1.setUsername("a");
        user1.setPassword("aaa111");
        userService.addUser(user1);

        UserEntity user2 = new UserEntity();
        user2.setName("Taghi");
        user2.setUsername("t");
        user2.setPassword("ttt111");
        userService.addUser(user2);
    }

    @Test
    public void addPoll() {
        final UserEntity user = userService.findById(1);

        pollService.addPoll("Favourite Iranian Football Club",
                new String[]{"Perspolis", "Esteghlal", "Trakhtor", "Sepahan", "Others"},
                user);


        pollService.addPoll("Favourite International Football Club",
                new String[]{"Barca", "Real Madrid", "Manchester United", "AC Milan", "Others"},
                user);
    }
}
