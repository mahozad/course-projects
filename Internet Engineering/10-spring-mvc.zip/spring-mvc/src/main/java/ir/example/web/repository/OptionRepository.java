package ir.example.web.repository;

import ir.example.web.model.entity.OptionEntity;
import org.springframework.data.repository.CrudRepository;


public interface OptionRepository extends CrudRepository<OptionEntity, Integer> {

}
