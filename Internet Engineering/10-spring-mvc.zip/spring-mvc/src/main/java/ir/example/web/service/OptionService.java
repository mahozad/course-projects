package ir.example.web.service;

import ir.example.web.model.entity.OptionEntity;
import ir.example.web.repository.OptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OptionService extends AbstractService<OptionEntity, Integer> {
    @Autowired
    private OptionRepository repository;


    @Override
    public OptionRepository getRepository() {
        return repository;
    }
}
