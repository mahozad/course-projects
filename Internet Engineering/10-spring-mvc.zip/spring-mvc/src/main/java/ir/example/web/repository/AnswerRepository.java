package ir.example.web.repository;

import ir.example.web.model.entity.AnswerEntity;
import ir.example.web.model.entity.PollEntity;
import ir.example.web.model.entity.UserEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface AnswerRepository extends CrudRepository<AnswerEntity, Integer> {
    boolean existsAnswerEntityByPollAndUser(PollEntity poll, UserEntity user);

    List<AnswerEntity> findAllByPoll(PollEntity poll);

    Long countAllByPoll(PollEntity poll);

    Long countAllByUser(UserEntity user);
}
