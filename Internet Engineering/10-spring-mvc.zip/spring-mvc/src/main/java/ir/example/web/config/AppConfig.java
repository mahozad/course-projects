package ir.example.web.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.bind.annotation.ControllerAdvice;

@Configuration
@ComponentScan("ir")
@PropertySource(name = "resource", value = {"classpath:config.properties", "classpath:fa_rb.properties"}, encoding = "UTF-8")
public class AppConfig {

}
