package ir.example.web.repository;

import ir.example.web.model.entity.PollEntity;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by sajjad on 5/2/2018.
 */

public interface PollRepository extends CrudRepository<PollEntity, Integer> {
    boolean existsBySubject(String subject);
}
