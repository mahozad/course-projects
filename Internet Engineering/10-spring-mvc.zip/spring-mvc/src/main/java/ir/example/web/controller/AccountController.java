package ir.example.web.controller;

import ir.example.web.model.entity.UserEntity;
import ir.example.web.service.PollService;
import ir.example.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;


@ControllerAdvice("ir.example.web.controller")
@Controller
@SessionAttributes({"user"})
public class AccountController {
    @Autowired
    private UserService userService;

    @Autowired
    private PollService pollService;

    @RequestMapping(value = {"/", "/login"}, method = RequestMethod.GET)
    protected String showLogin(Model model) {
        if (!model.containsAttribute("user")) {
            model.addAttribute("login_user", new UserEntity());
            return "login";
        }
        model.addAttribute("allPolls", pollService.findAll());
        return "home";
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    protected String processLogin(@ModelAttribute("login_user") UserEntity loginUser, Model model) {
        if (!model.containsAttribute("user")) {
            UserEntity userEntity = userService.verifyUser(loginUser.getUsername(), loginUser.getPassword());
            model.addAttribute("user", userEntity);
        }
        model.addAttribute("allPolls", pollService.findAll());
        return "redirect:/";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    protected ModelAndView processLogout(HttpSession session, Model model) {
        session.invalidate();
        model.asMap().clear();
        return new ModelAndView("redirect", "retitle", "You are successfully logged out!");
    }

    @RequestMapping(value = "/signup", method = RequestMethod.GET)
    public ModelAndView showSignup() {
        return new ModelAndView("signup", "signup_user", new UserEntity());
    }

    @RequestMapping(value = "/signup", method = RequestMethod.POST)
    protected ModelAndView processSignup(@ModelAttribute("signup_user") UserEntity signupUser) {
        userService.save(signupUser);
        return new ModelAndView("redirect", "retitle", "You are successfully signed up!");
    }
}
