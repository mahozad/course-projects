package ir.example.web.controller;

import ir.example.web.model.entity.PollEntity;
import ir.example.web.model.entity.UserEntity;
import ir.example.web.service.AnswerService;
import ir.example.web.service.PollService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;


@Controller
@SessionAttributes({"user"})
public class PollController {
    @Autowired
    private PollService pollService;

    @Autowired
    private AnswerService answerService;

    @RequestMapping(value = "/vote/{pid}", method = RequestMethod.GET)
    protected ModelAndView showResult(@PathVariable("pid") int pid, @ModelAttribute("user") UserEntity userEntity) {
        final PollEntity pollEntity = pollService.find(pid);

        ModelAndView model = new ModelAndView();
        model.addObject("poll", pollEntity);

        if (answerService.alreadyAnswer(pollEntity, userEntity) || (pollEntity.getStatus() == 1)) {
            model.addObject("vote_count", answerService.countAnswer(pollEntity));
            model.addObject("poll_report", pollService.getPollReport(pollEntity));
            model.setViewName("result");
        } else {
            model.setViewName("vote");
        }

        return model;
    }

    @RequestMapping(value = "/save/{pid}", method = RequestMethod.POST)
    protected ModelAndView saveVote(
            @PathVariable("pid") int pid,
            @RequestParam("choice") Integer choiceID,
            @ModelAttribute("user") UserEntity user) {

        PollEntity pollEntity = pollService.votePoll(pid, user, choiceID);
        ModelAndView model = new ModelAndView("result");
        model.addObject("vote_count", answerService.countAnswer(pollEntity));
        model.addObject("poll_report", pollService.getPollReport(pollEntity));
        model.addObject("poll", pollEntity);
        return model;
    }

    @RequestMapping(value = "/new", method = RequestMethod.GET)
    protected String showNewPoll() {
        return "new";
    }

    @RequestMapping(value = "/new", method = RequestMethod.POST)
    protected String newPoll(@RequestParam(value = "subject") String subject,
                             @RequestParam(value = "choices[]") String choices[],
                             @ModelAttribute("user") UserEntity user) {
        pollService.addPoll(subject, choices, user);
        return "redirect:/";
    }

    @RequestMapping(value = "/mark", method = RequestMethod.GET)
    protected String markPoll(@RequestParam(value = "pid") int pid,
                              @RequestParam(value = "type") String type,
                              @ModelAttribute("user") UserEntity user) {
        pollService.markPoll(pid, type, user);
        return "redirect:/";
    }

}
