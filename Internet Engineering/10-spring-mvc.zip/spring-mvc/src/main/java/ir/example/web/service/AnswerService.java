package ir.example.web.service;

import ir.example.web.model.entity.AnswerEntity;
import ir.example.web.model.entity.OptionEntity;
import ir.example.web.model.entity.PollEntity;
import ir.example.web.model.entity.UserEntity;
import ir.example.web.repository.AnswerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnswerService extends AbstractService<AnswerEntity, Integer> {
    @Autowired
    private AnswerRepository repository;

    List<AnswerEntity> findAll(PollEntity poll) {
        return repository.findAllByPoll(poll);
    }

    public boolean alreadyAnswer(PollEntity poll, UserEntity user) {
        return repository.existsAnswerEntityByPollAndUser(poll, user);
    }

    void answerPoll(PollEntity poll, UserEntity user, OptionEntity option) {
        final AnswerEntity answer = new AnswerEntity();
        answer.setPoll(poll);
        answer.setUser(user);
        answer.setOption(option);

        save(answer);
    }

    public Long countAnswer(PollEntity poll) {
        return repository.countAllByPoll(poll);
    }

    Long countAnswer(UserEntity user) {
        return repository.countAllByUser(user);
    }

    @Override
    public AnswerRepository getRepository() {
        return repository;
    }
}
