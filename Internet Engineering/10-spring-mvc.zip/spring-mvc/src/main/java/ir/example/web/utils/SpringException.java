package ir.example.web.utils;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.ArrayList;

/**
 * Created by sajjad on 12/9/2017.
 */

@ResponseStatus(value= HttpStatus.BAD_REQUEST, reason="Bad Request")
public class SpringException extends RuntimeException {
    private ArrayList<String> exceptionMsgs = new ArrayList<>();
    private String exceptionTitle;
    private String exceptionBackLink;
    private String exceptionBackTitle;

    public SpringException(String title, String backlink, String backtitle, String exceptionMsg) {
        exceptionTitle = title;
        exceptionBackLink = backlink;
        exceptionBackTitle = backtitle;
        exceptionMsgs.add(exceptionMsg);
    }

    public SpringException(String title, String backlink, String backtitle) {
        exceptionTitle = title;
        exceptionBackLink = backlink;
        exceptionBackTitle = backtitle;
    }

    public String getTitle() {
        return exceptionTitle;
    }

    public String getBacklink() {
        return exceptionBackLink;
    }

    public String getBacktitle() {
        return exceptionBackTitle;
    }

    public ArrayList<String> getMessages() {
        return exceptionMsgs;
    }

    public void addMessage(String exceptionMsg) {
        exceptionMsgs.add(exceptionMsg);
    }

    public boolean isExcepted() {
        return !exceptionMsgs.isEmpty();
    }
}
