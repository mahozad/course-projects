package ir.example.web.model;


public class UserMessage {
    private final String name;
    private final Long pollCount;

    public UserMessage(String name, Long pollCount) {
        this.name = name;
        this.pollCount = pollCount;
    }

    public String getName() {
        return name;
    }

    public Long getPollCount() {
        return pollCount;
    }
}
