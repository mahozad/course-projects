package ir.example.web.service;

import ir.example.web.model.entity.BaseEntity;
import org.springframework.data.repository.CrudRepository;

public abstract class AbstractService<T extends BaseEntity, ID> {

    public abstract CrudRepository<T, ID> getRepository();

    public T save(T entity) {
        getRepository().save(entity);
        return entity;
    }

    public void delete(T entity) {
        getRepository().delete(entity);
    }


    public T findById(ID id) {
        if (id == null) {
            return null;
        }
        return getRepository().findById(id).orElse(null);
    }

    public Iterable<T> findAll() {
        return getRepository().findAll();
    }

    public long count() {
        return getRepository().count();
    }

}
