package ir.example.web.service;

import ir.example.web.model.entity.UserEntity;
import ir.example.web.model.UserMessage;
import ir.example.web.repository.UserRepository;
import ir.example.web.utils.SpringException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService extends AbstractService<UserEntity, Integer> {
    @Autowired
    private UserRepository repository;

    @Autowired
    private AnswerService answerService;


    public void addUser(UserEntity userEntity) {
        if ((userEntity.getName() == null) || userEntity.getName().equals("") || (userEntity.getUsername() == null) || userEntity.getUsername().equals("")) {
            throw new SpringException("Signup", "/signup", "signup", "name and username fields must be filled out!");
        }

        if (userEntity.getPassword().length() < 4) {
            throw new SpringException("Signup", "/signup", "signup", "password length should be at least 4!");
        }

        String name = userEntity.getName();
        userEntity.setName(name.substring(0, 1).toUpperCase() + name.substring(1));

        final boolean exists = repository.existsByUsername(userEntity.getUsername());
        if (exists) {
            throw new SpringException("Signup", "/signup", "signup", "This username is already taken!");
        }

        save(userEntity);
    }

    public UserEntity verifyUser(String username, String password) {
        final UserEntity user = repository.findByUsernameAndPassword(username, password);
        if (user == null) {
            throw new SpringException("Login", "/login", "Login", "Username/password incorrect!");
        }
        return user;
    }

    public List<UserMessage> getUserMessages() {
        final Iterable<UserEntity> userEntities = repository.findAll();
        final List<UserMessage> messages = new ArrayList<>();

        for (UserEntity userEntity : userEntities) {
            messages.add(new UserMessage(userEntity.getName(), answerService.countAnswer(userEntity)));
        }

        return messages;
    }

    @Override
    public UserRepository getRepository() {
        return repository;
    }
}
