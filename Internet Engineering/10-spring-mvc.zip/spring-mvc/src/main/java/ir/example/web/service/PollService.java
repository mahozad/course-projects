package ir.example.web.service;

import ir.example.web.model.entity.AnswerEntity;
import ir.example.web.model.entity.OptionEntity;
import ir.example.web.model.entity.PollEntity;
import ir.example.web.model.entity.UserEntity;
import ir.example.web.repository.PollRepository;
import ir.example.web.utils.SpringException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PollService extends AbstractService<PollEntity, Integer> {
    @Autowired
    private PollRepository repository;

    @Autowired
    private AnswerService answerService;

    @Autowired
    private OptionService optionService;

    @Autowired
    private UserService userService;


    public PollEntity votePoll(Integer pollID, UserEntity userEntity, Integer optionID) {
        final PollEntity pollEntity = find(pollID);
        if (pollEntity == null) {
            throw new SpringException("Save", "/", "Home", "Unknown poll!");
        }

        if (answerService.alreadyAnswer(pollEntity, userEntity)) {
            throw new SpringException("Save", "/", "Home", "You have already voted!");
        }

        final OptionEntity optionEntity = optionService.findById(optionID);
        if (optionEntity == null) {
            throw new SpringException("Save", "/", "Home", "Invalid choice!");
        }
        answerService.answerPoll(pollEntity, userEntity, optionEntity);

        return pollEntity;
    }

    public PollEntity find(Integer pid) {
        final PollEntity pollEntity = findById(pid);
        if (pollEntity == null) {
            throw new SpringException("Vote", "/", "Home", "Invalid poll id!");
        } else if (pollEntity.getStatus() == 2) {
            throw new SpringException("Vote", "/", "Home", "Deleted poll!");
        }
        return pollEntity;
    }

    public List<String> getPollReport(PollEntity poll) {
        final List<AnswerEntity> entities = answerService.findAll(poll);
        final int totalAnswer = entities.size();

        final Map<OptionEntity, Integer> map = new HashMap<>();
        for (AnswerEntity answer : entities) {
            final Integer count = map.getOrDefault(answer.getOption(), 0);
            map.put(answer.getOption(), count + 1);
        }

        final List<String> results = new ArrayList<>();
        for (Map.Entry<OptionEntity, Integer> entry : map.entrySet()) {
            final OptionEntity option = entry.getKey();
            final Integer count = entry.getValue();

            final String result = option.getContent() + ": " + String.format("%.1f", (float) (count * 100.0F / totalAnswer)) + "%";
            results.add(result);
        }

        return results;
    }

    public void addPoll(String subject, String options[], UserEntity userEntity) {
        if ((subject == null) || (options == null)) {
            throw new SpringException("New Poll", "/", "Home", "Subject/Choices should be filled out!");
        }

        if (repository.existsBySubject(subject)) {
            throw new SpringException("New Poll", "/", "Home", "This username is already taken!");
        }
        final PollEntity pollEntity = new PollEntity();
        pollEntity.setSubject(subject);
        pollEntity.setOwner(userEntity);
        pollEntity.setStatus(0);

        final List<OptionEntity> optionEntities = new ArrayList<>();
        for (String content : options) {
            final OptionEntity entity = new OptionEntity();
            entity.setPoll(pollEntity);
            entity.setContent(content);

            optionEntities.add(entity);
        }
        pollEntity.setOptions(optionEntities);

        save(pollEntity);
    }

    public void markPoll(Integer pollID, String status, UserEntity user) {
        final PollEntity pollEntity = find(pollID);
        if (pollEntity == null) {
            throw new SpringException("Mark Poll", "/", "Home", "Unknown poll id!");
        }

        if (!pollEntity.getOwner().equals(user)) {
            throw new SpringException("Mark Poll", "/", "Home", "Permission denied!");
        }

        if (pollEntity.getStatus() != 0) {
            throw new SpringException("Mark Poll", "/", "Home", "Already marked!");
        }

        if ((status == null) || (!status.equals("close") && !status.equals("delete"))) {
            throw new SpringException("Mark Poll", "/", "Home", "Invalid mark type!");
        }

        if (status.equals("close")) {
            pollEntity.setStatus(1);
            save(pollEntity);
        } else {
            pollEntity.setStatus(2);
            save(pollEntity);
        }
    }

    @Override
    public CrudRepository<PollEntity, Integer> getRepository() {
        return repository;
    }
}
