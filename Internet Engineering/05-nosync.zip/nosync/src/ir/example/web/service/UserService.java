package ir.example.web.service;

import ir.example.web.model.User;

import java.util.HashSet;
import java.util.Set;

public class UserService {

    private final Set<User> users;

    public UserService() {
        this.users = new HashSet<>();

        users.add(new User("a", 0));
        users.add(new User("b", 0));
        users.add(new User("c", 0));
        users.add(new User("d", 0));
        users.add(new User("e", 0));
        users.add(new User("f", 0));
    }

    public User find(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }
}
