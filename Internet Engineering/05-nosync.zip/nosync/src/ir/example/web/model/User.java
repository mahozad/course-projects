package ir.example.web.model;

public class User {
    private static Integer nextID = 0;
    private final Integer id;
    private final String username;
    private Integer charge;

    public User(String username, int initial) {
        this.id = nextID;
        this.username = username;
        this.charge = initial;
        nextID++;
    }

    public Integer getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public Integer getCharge() { return charge; }

    public Integer addCharge(int add) {
        charge += add;
        try {
            Thread.sleep(3000);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return charge;
    }
}
