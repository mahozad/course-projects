package ir.example.web.servlet;

import ir.example.web.model.User;
import ir.example.web.service.UserService;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet(urlPatterns = "/user")
public class UserServlet extends HttpServlet {
    private UserService userService;

    @Override
    public void init(ServletConfig config) throws ServletException {
        userService = new UserService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        final String username = req.getParameter("username");
        final Integer add = Integer.valueOf(req.getParameter("add"));
        final User user = userService.find(username);

        if (user != null) {
            int charge = user.addCharge(add);
            try (final PrintWriter writer = resp.getWriter()) {
                writer.println("<html>");
                writer.println("<body>");
                writer.println("The amount of remaining charge: " + charge);
                writer.println("</body>");
                writer.println("</html>");
            }
        }
    }
}
