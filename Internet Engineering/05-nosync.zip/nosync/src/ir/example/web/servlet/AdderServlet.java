
package ir.example.web.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

@WebServlet(urlPatterns = "/add")
public class AdderServlet extends HttpServlet {
    public Map<String, String> params = new HashMap<>();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        try (final PrintWriter writer = resp.getWriter()) {
            extractParams(req.getQueryString());
            try {
                Thread.sleep(3000);
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            final int n1 = Integer.parseInt(params.get("n1"));
            final int n2 = Integer.parseInt(params.get("n2"));
            final int result = n1 + n2;

            writer.println("<html>");
            writer.println("<body>");
            writer.println(n1 + " + " + n2 + " = " + result);
            writer.println("</body>");
            writer.println("</html>");
        }
    }

    private void extractParams(String queryString) throws IOException {
        if (queryString != null) {
            final String[] paramPairs = queryString.split("\\&");
            for (String paramPair : paramPairs) {
                final String[] split = paramPair.split("=");
                params.put(split[0], split[1]);
            }
        }
    }
}
