package ir.example.httpserver.handler;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import ir.example.httpserver.model.StatusCode;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by mohammadchangani on 10/4/17.
 * internet-engineering
 */
public abstract class ServiceHandler implements HttpHandler {
    final Map<String, String> params;

    public ServiceHandler() {
        this.params = new HashMap<>();
    }

    public abstract void execute(PrintWriter out) throws IOException;

    private void extractParams(HttpExchange exchange) throws IOException {
        final String[] paramPairs = exchange.getRequestURI().getQuery().split("\\&");

        for (String paramPair : paramPairs) {
            final String[] split = paramPair.split("=");
            params.put(split[0], split[1]);
        }
    }

    private void sendResponse(HttpExchange exchange, byte[] result) throws IOException {
        final Headers headers = exchange.getResponseHeaders();
        headers.add("Date", Calendar.getInstance().getTime().toString());
        headers.add("Content-Type", "text/html");

        exchange.sendResponseHeaders(StatusCode.OK.getCode(), result.length);

        try (final OutputStream out = exchange.getResponseBody()) {
            out.write(result);
        }
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        extractParams(exchange);

        final StringWriter writer = new StringWriter();
        execute(new PrintWriter(writer));

        sendResponse(exchange, writer.toString().getBytes());
    }
}
