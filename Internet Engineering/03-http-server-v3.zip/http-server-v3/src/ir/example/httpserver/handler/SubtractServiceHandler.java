package ir.example.httpserver.handler;

import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by mohammadchangani on 10/4/17.
 * internet-engineering
 */
public class SubtractServiceHandler extends ServiceHandler{

    @Override
    public void execute(PrintWriter out) throws IOException {
        final int n1 = Integer.parseInt(params.get("n1"));
        final int n2 = Integer.parseInt(params.get("n2"));
        final int result = n1 - n2;

        out.println("<html>");
        out.println("<body>");
        out.println(n1 + " - " + n2 + " = " + result);
        out.println("</body>");
        out.println("</html>");
    }
}
