package ir.example.httpserver;

import com.sun.net.httpserver.HttpServer;
import ir.example.httpserver.handler.CalcHttpHandlerImpl;
import ir.example.httpserver.handler.FileHttpHandlerImpl;
import ir.example.httpserver.handler.HelloHttpHandlerImpl;

import java.net.InetSocketAddress;

/**
 * Created by mohammadchangani on 10/4/17.
 * internet-engineering
 */
public class CoolHttpServer {
    public static void main(String[] args) throws Exception {
        final HttpServer server
                = HttpServer.create(new InetSocketAddress(9077), 0);


        server.createContext("/hello", new HelloHttpHandlerImpl());
        server.createContext("/file", new FileHttpHandlerImpl());
        server.createContext("/calc", new CalcHttpHandlerImpl());
//        server.setExecutor(Executors.newCachedThreadPool());

        server.start();
    }
}
