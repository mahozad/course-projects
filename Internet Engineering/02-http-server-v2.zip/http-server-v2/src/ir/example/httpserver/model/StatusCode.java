package ir.example.httpserver.model;

public enum StatusCode {
    OK(200, "OK"),
    BAD_REQUEST(401, "Bad Request"),
    NOT_FOUND(404, "Not Found"),
    NOT_IMPLEMENT(501, "Not Implement");

    private final int code;
    private final String name;

    StatusCode(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return code + " - " + name;
    }
}