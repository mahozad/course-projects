package ir.example.httpserver.handler;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import ir.example.httpserver.model.StatusCode;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by mohammadchangani on 10/4/17.
 * internet-engineering
 */
public class CalcHttpHandlerImpl implements HttpHandler {
    public void handle(HttpExchange exchange) throws IOException {
        final String operation = exchange.getRequestURI().getPath().replace("/calc/", "");
        final String[] paramPairs = exchange.getRequestURI().getQuery().split("\\&");

        final Map<String, String> params = new HashMap<>();
        for (String paramPair : paramPairs) {
            final String[] split = paramPair.split("=");
            params.put(split[0], split[1]);
        }

        final StringBuilder response = new StringBuilder();
        if (operation.equals("add")) {
            final int n1 = Integer.parseInt(params.get("n1"));
            final int n2 = Integer.parseInt(params.get("n2"));
            final int result = n1 + n2;

            response.append("<html>");
            response.append("<body>");
            response.append("<h1>");
            response.append(n1).append(" + ").append(n2).append(" = ").append(result);
            response.append("</h1>");
            response.append("</body>");
            response.append("</html>");


            final Headers headers = exchange.getResponseHeaders();
            headers.add("Date", Calendar.getInstance().getTime().toString());
            headers.add("Content-Type", "text/html");

            exchange.sendResponseHeaders(StatusCode.OK.getCode(), response.toString().getBytes().length);

            try (final OutputStream out = exchange.getResponseBody()) {
                out.write(response.toString().getBytes());
            }
        }
    }
}
