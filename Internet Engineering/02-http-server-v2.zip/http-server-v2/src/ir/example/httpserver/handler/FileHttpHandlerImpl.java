package ir.example.httpserver.handler;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import ir.example.httpserver.model.StatusCode;
import ir.example.httpserver.utils.ContentTypeUtils;

import java.io.*;
import java.util.Calendar;

/**
 * Created by mohammadchangani on 10/4/17.
 * internet-engineering
 */
public class FileHttpHandlerImpl implements HttpHandler {

    public void handle(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath();
        path = path.replace("/file/", "");

        final File file = new File("/root/http-server/docs/" + path);
        if (!file.exists()) {
            exchange.sendResponseHeaders(StatusCode.NOT_FOUND.getCode(), -1);
            return;
        }
        final String contentType = ContentTypeUtils.findContentType(path);

        final Headers headers = exchange.getResponseHeaders();
        headers.add("Date", Calendar.getInstance().getTime().toString());
        headers.add("Content-Type", contentType);

        exchange.sendResponseHeaders(StatusCode.OK.getCode(), file.length());

        try (final OutputStream out = exchange.getResponseBody()) {
            try(final InputStream payloadFile = new BufferedInputStream(new FileInputStream(file))){
                while (true) {
                    final int b = payloadFile.read();
                    if (b == -1) {
                        break;
                    }
                    out.write(b);
                }
            }
        }
    }
}
