package ir.example.httpserver.handler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Created by mohammadchangani on 10/4/17.
 * internet-engineering
 */
public class HelloHttpHandlerImpl implements HttpHandler {


    public void handle(HttpExchange exchange) throws IOException {
        try {
//            System.out.println("*******");
//            Thread.sleep(100_000);
            final String response = "Hello!!";
            exchange.sendResponseHeaders(200, response.length());

            try (final OutputStream out = exchange.getResponseBody()) {
                out.write(response.getBytes());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
