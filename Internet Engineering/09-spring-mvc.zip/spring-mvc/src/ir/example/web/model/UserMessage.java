package ir.example.web.model;

/**
 * Created by sajjad on 12/11/2017.
 */

public class UserMessage {
    String name;
    int pollCount;

    public UserMessage(String name, int pollCount) {
        this.name = name;
        this.pollCount = pollCount;
    }

    public String getName() {
        return name;
    }

    public int getPollCount() {
        return pollCount;
    }
}
