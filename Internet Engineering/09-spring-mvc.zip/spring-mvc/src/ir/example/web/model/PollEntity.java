package ir.example.web.model;

import java.util.HashMap;
import java.util.Map;

//POJO
public class PollEntity {
    private Integer id;
    private Integer ownerId;
    private String subject;
    private String choices[];
    private Integer status = 0;
    private final Map<Integer, Integer> userChoices = new HashMap<Integer, Integer>();

    public Integer getId() { return id; }

    public void setId(Integer id) { this.id = id; }

    public Integer getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Integer ownerId) {
        this.ownerId = ownerId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String[] getChoices() {
        return choices;
    }

    public void setChoices(String choices[]) {
        this.choices = choices;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Map<Integer, Integer> getUserChoices() {
        return userChoices;
    }

    @Override
    public String toString() {
        return String.format("Poll[id='%d', name='%s']", id, subject);
    }

}
