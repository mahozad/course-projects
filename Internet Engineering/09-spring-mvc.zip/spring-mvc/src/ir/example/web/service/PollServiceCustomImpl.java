package ir.example.web.service;

import ir.example.web.model.PollEntity;
import ir.example.web.model.UserEntity;
import ir.example.web.repository.PollRepository;
import ir.example.web.utils.SpringException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import java.util.Set;

/**
 * Created by sajjad on 5/3/2018.
 */

@Service
public class PollServiceCustomImpl implements PollService {
    @Autowired
    @Qualifier("pollRepository")
    PollRepository pollRepository;

    public Set<PollEntity> getAllPolls() {
        return pollRepository.getAllPolls();
    }

    public PollEntity votePoll(Integer pid, UserEntity userEntity, String choice) {
        PollEntity pollEntity = pollRepository.findPoll(pid);
        if ((pollEntity == null))
            throw new SpringException("Save", "/", "Home", "Unknown poll!");
        if (pollRepository.alreadyChosen(pollEntity, userEntity))
            throw new SpringException("Save", "/", "Home", "You have already voted!");
        if (!pollRepository.votePoll(pollEntity, userEntity, choice))
            throw new SpringException("Save", "/", "Home", "Invalid choice!");
        return pollEntity;
    }

    public PollEntity findPoll(Integer pid) {
        PollEntity pollEntity = pollRepository.findPoll(pid);
        if (pollEntity == null)
            throw new SpringException("Vote", "/", "Home", "Invalid poll id!");
        else if (pollEntity.getStatus() == 2)
            throw new SpringException("Vote", "/", "Home", "Deleted poll!");
        return pollEntity;
    }

    public boolean alreadyChosen(PollEntity pollEntity, UserEntity userEntity) {
        return pollRepository.alreadyChosen(pollEntity, userEntity);
    }
    public String[] getPollReport(PollEntity pollEntity) {
        return pollRepository.getPollReport(pollEntity);
    }

    public Integer getPollVoteCount(PollEntity pollEntity) {
        return pollRepository.getPollVoteCount(pollEntity);
    }

    public void addPoll(String subject, String choices[], Integer owenerId) {
        SpringException ex = new SpringException("New Poll", "/", "Home");
        if ((subject == null) || (choices == null))
            ex.addMessage("Subject/Choices should be filled out!");
        if (!ex.isExcepted()) {
            if (!pollRepository.addPoll(subject, choices, owenerId))
                ex.addMessage("This username is already taken!");
        }
        if (ex.isExcepted())
            throw ex;
    }

    public void markPoll(Integer pid, String type, Integer userId) {
        SpringException ex = new SpringException("Mark Poll", "/", "Home");
        PollEntity pollEntity = pollRepository.findPoll(pid);
        if (pollEntity == null)
            ex.addMessage("Unknown poll id!");
        else if (pollEntity.getOwnerId() == userId) {
            if (pollEntity.getStatus() == 0) {
                if ((type == null) || (!type.equals("close") && !type.equals("delete"))) {
                    ex.addMessage("Invalid mark type!");
                } else {
                    //Do not mark PollEntity
                    if (type.equals("close"))
                        pollRepository.markPoll(pollEntity, 1);
                    else
                        pollRepository.markPoll(pollEntity, 2);
                }
            } else {
                ex.addMessage("Already marked!");
            }
        } else {
            ex.addMessage("Permission denied!");
        }
        if (ex.isExcepted())
            throw ex;
    }
}
