package ir.example.web.service;

import ir.example.web.model.PollEntity;
import ir.example.web.model.UserEntity;
import java.util.Set;

/**
 * Created by sajjad on 4/29/2018.
 */

public interface PollService {
    public Set<PollEntity> getAllPolls();

    public PollEntity votePoll(Integer pid, UserEntity userEntity, String choice);

    public PollEntity findPoll(Integer pid);

    public boolean alreadyChosen(PollEntity pollEntity, UserEntity userEntity);

    public String[] getPollReport(PollEntity pollEntity);

    public Integer getPollVoteCount(PollEntity pollEntity);

    public void addPoll(String subject, String choices[], Integer owenerId);

    public void markPoll(Integer pid, String type, Integer userId);
}