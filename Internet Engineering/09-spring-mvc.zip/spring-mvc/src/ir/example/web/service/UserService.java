package ir.example.web.service;

import ir.example.web.model.UserEntity;
import ir.example.web.model.UserMessage;

/**
 * Created by sajjad on 4/29/2018.
 */

public interface UserService {
    public UserEntity createUserEntity();

    public void addUser(UserEntity userEntity);

    public UserEntity verifyUser(String username, String password);

    public UserMessage[] getUserMessages();
}
