package ir.example.web.service;

import ir.example.web.model.UserEntity;
import ir.example.web.model.UserMessage;
import ir.example.web.repository.PollRepository;
import ir.example.web.repository.UserRepository;
import ir.example.web.utils.SpringException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Set;

/**
 * Created by sajjad on 5/3/2018.
 */

@Service
public class UserServiceCustomImpl implements UserService {
    @Autowired
    UserRepository userRepository;
    @Autowired
    PollRepository pollRepository;

    public UserEntity createUserEntity() {
        return userRepository.createUserEntity();
    }

    public void addUser(UserEntity userEntity) {
        SpringException ex = new SpringException("Signup", "/signup", "signup");
        if ((userEntity.getName() == null) || userEntity.getName().equals("") || (userEntity.getUsername() == null) || userEntity.getUsername().equals(""))
            ex.addMessage("name and username fields must be filled out!");
        if (userEntity.getPassword().length() < 4)
            ex.addMessage("password length should be at least 4!");

        if (!ex.isExcepted()) {
            String name = userEntity.getName();
            userEntity.setName(name.substring(0, 1).toUpperCase() + name.substring(1));
            if (!userRepository.addUser(userEntity))
                ex.addMessage("This username is already taken!");
        }

        if (ex.isExcepted())
            throw ex;
    }

    public UserEntity verifyUser(String username, String password) {
        UserEntity user = userRepository.findUser(username, password);
        if (user == null)
            throw new SpringException("Login","/login", "Login", "Username/password incorrect!");
        return user;
    }

    public UserMessage[] getUserMessages() {
        Set<UserEntity> allUsers = userRepository.getAllUsers();
        UserMessage msg[] = new UserMessage[allUsers.size()];
        int i = 0;
        for (UserEntity userEntity: allUsers) {
            msg[i] = new UserMessage(userEntity.getName(), pollRepository.getUserVoteCount(userEntity));
            i++;
        }
        return msg;
    }
}
