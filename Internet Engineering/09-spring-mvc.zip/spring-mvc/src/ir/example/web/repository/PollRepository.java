package ir.example.web.repository;

import ir.example.web.model.PollEntity;
import ir.example.web.model.UserEntity;
import java.util.Set;

/**
 * Created by sajjad on 5/2/2018.
 */

public interface PollRepository {
    public boolean addPoll(String subject, String choices[], Integer ownerId);

    public PollEntity findPoll(Integer id);

    public Set<PollEntity> getAllPolls();

    public boolean alreadyChosen(PollEntity poll, UserEntity user);

    public boolean votePoll(PollEntity pollEntity, UserEntity userEntity, String choice);

    public int getPollVoteCount(PollEntity poll);

    public int getUserVoteCount(UserEntity user);

    public String[] getPollReport(PollEntity pollEntity);

    public void markPoll(PollEntity pollEntity, int status);
}
