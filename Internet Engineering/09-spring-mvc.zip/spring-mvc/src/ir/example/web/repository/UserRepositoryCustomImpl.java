package ir.example.web.repository;

import ir.example.web.model.UserEntity;
import org.springframework.stereotype.Repository;
import java.util.HashSet;
import java.util.Set;

@Repository("userRepository")
public class UserRepositoryCustomImpl implements UserRepository {
    private final Set<UserEntity> allUsers = new HashSet<>();

    public UserRepositoryCustomImpl() {
        UserEntity user1 = new UserEntity();
        user1.setName("Ali");
        user1.setUsername("a");
        user1.setPassword("aaa111");
        addUser(user1);

        UserEntity user2 = new UserEntity();
        user2.setName("Taghi");
        user2.setUsername("t");
        user2.setPassword("ttt111");
        addUser(user2);
    }

    public UserEntity createUserEntity() {
        return new UserEntity();
    }

    public synchronized boolean addUser(UserEntity userEntity) {
        if (findUser(userEntity.getUsername()) == null) {
            userEntity.setId(allUsers.size() + 1);
            allUsers.add(userEntity);
            return true;
        }
        return false;
    }

    public Set<UserEntity> getAllUsers() {
        return allUsers;
    }

    public UserEntity findUser(Integer id) {
        for (UserEntity userEntity : allUsers) {
            if (userEntity.getId().equals(id)) {
                return userEntity;
            }
        }
        return null;
    }

    public UserEntity findUser(String username) {
        for (UserEntity userEntity : allUsers) {
            if (userEntity.getUsername().equals(username)) {
                return userEntity;
            }
        }
        return null;
    }

    public UserEntity findUser(String Username, String password) {
        for (UserEntity userEntity : allUsers) {
            if (userEntity.getUsername().equals(Username) && userEntity.getPassword().equals(password)) {
                return userEntity;
            }
        }
        return null;
    }
}
