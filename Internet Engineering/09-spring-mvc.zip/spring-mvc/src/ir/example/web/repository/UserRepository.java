package ir.example.web.repository;

import ir.example.web.model.UserEntity;
import java.util.Set;

/**
 * Created by sajjad on 5/2/2018.
 */

public interface UserRepository {
    public UserEntity createUserEntity();

    public boolean addUser(UserEntity userEntity);

    public Set<UserEntity> getAllUsers();

    public UserEntity findUser(Integer id);

    public UserEntity findUser(String Username, String password);
}
