package ir.example.web.repository;

import  ir.example.web.model.PollEntity;
import ir.example.web.model.UserEntity;
import org.springframework.stereotype.Repository;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

@Repository("pollRepository")
public class PollRepositoryCustomImpl implements PollRepository {
    private final Set<PollEntity> allPolls = new LinkedHashSet<>();

    public PollRepositoryCustomImpl() {
        addPoll("Favourite Iranian Football Club", new String[]{"Perspolis","Esteghlal", "Trakhtor", "Sepahan", "Others"}, 1);
        addPoll("Favourite International Football Club", new String[]{"Barca","Real Madrid", "Manchester United", "AC Milan", "Others"}, 1);
    }

    public synchronized boolean addPoll(String subject, String choices[], Integer ownerId) {
        if (findPoll(subject) == null) {
            PollEntity pollEntity = new PollEntity();
            pollEntity.setSubject(subject);
            pollEntity.setChoices(choices);
            pollEntity.setOwnerId(ownerId);
            pollEntity.setId(allPolls.size() + 1);
            allPolls.add(pollEntity);
            return true;
        }
        return false;
    }

    public PollEntity findPoll(Integer id) {
        for (PollEntity poll : allPolls)
            if (poll.getId() == id)
                return poll;
        return null;
    }

    private PollEntity findPoll(String name) {
        for (PollEntity poll : allPolls) {
            if (poll.getSubject().equals(name)) {
                return poll;
            }
        }
        return null;
    }

    public Set<PollEntity> getAllPolls() {
        return allPolls;
    }

    public boolean alreadyChosen(PollEntity poll, UserEntity user) {
        Map userChoices = poll.getUserChoices();
        if (userChoices.get(user.getId()) != null)
            return true;
        return false;
    }

    public boolean votePoll(PollEntity poll, UserEntity user, String chosen) {
        if (chosen == null)
            return false;
        int id = 0;
        String choices[] = poll.getChoices();
        for (String choice : choices) {
            if (choice.equals(chosen))
                break;
            id++;
        }
        Map userChoices = poll.getUserChoices();
        if (id < choices.length) {
            userChoices.put(user.getId(), id);
            return true;
        }
        return false;
    }

    public String[] getPollReport(PollEntity poll) {
        String choices[] = poll.getChoices();
        Map<Integer, Integer> userChoices = poll.getUserChoices();
        int count[] = new int[choices.length], total = 0;
        for (Map.Entry<Integer, Integer> entry : userChoices.entrySet()) {
            count[entry.getValue().intValue()]++;
            total++;
        }

//        if (total == 0)
//            return null;

        String output[] = new String[choices.length];
        int id = 0;
        for (String choice : choices) {
            output[id] = choice + ": " + String.format("%.1f", (float) (count[id] * 100.0F / total))  + "%";
            id++;
        }
        return output;
    }

    public int getPollVoteCount(PollEntity poll) {
        Map userChoices = poll.getUserChoices();
        return userChoices.size();
    }

    public int getUserVoteCount(UserEntity user) {
        int voteCount = 0;
        for (PollEntity poll : allPolls) {
            if (alreadyChosen(poll, user))
                voteCount++;
        }
        return voteCount;
    }

    public void markPoll(PollEntity pollEntity, int status) {
        pollEntity.setStatus(status);
    }
}
