package ir.example.web.controller;

import ir.example.web.model.UserMessage;
import ir.example.web.repository.UserRepository;
import ir.example.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestfullController {
    @Autowired
    private UserService userService;

    //@ResponseBody
    @RequestMapping(path="/rest/users", produces=MediaType.APPLICATION_JSON_VALUE)
    public UserMessage[] message() {
        return userService.getUserMessages();
    }
}
