package ir.example.web.controller;

import ir.example.web.model.UserEntity;
import ir.example.web.service.PollService;
import ir.example.web.service.UserService;
import ir.example.web.utils.SpringException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@ControllerAdvice("ir.example.web.controller")
@Controller
@SessionAttributes({"user"})
public class AccountController {
    @Autowired
    private UserService userService;
    @Autowired
    private PollService pollService;

    @RequestMapping(value = {"/", "/login"}, method = RequestMethod.GET)
    protected String showLogin(Model model) {
        if(!model.containsAttribute("user")) {
            model.addAttribute("login_user", userService.createUserEntity());
            return "login";
        }
        model.addAttribute("allPolls", pollService.getAllPolls());
        return "home";
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    protected String processLogin(@ModelAttribute("login_user") UserEntity loginUser, Model model) {
        if (!model.containsAttribute("user")) {
            UserEntity userEntity = userService.verifyUser(loginUser.getUsername(), loginUser.getPassword());
            model.addAttribute("user", userEntity);
        }
        return "redirect:/";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    protected ModelAndView processLogout(HttpSession session, Model model) {
        session.invalidate();
        model.asMap().clear();
        return new ModelAndView("redirect", "retitle", "You are successfully logged out!");
    }

    @RequestMapping(value = "/signup", method = RequestMethod.GET)
    public ModelAndView showSignup() {
        return new ModelAndView("signup", "signup_user", userService.createUserEntity());
    }

    @RequestMapping(value = "/signup", method = RequestMethod.POST)
    protected ModelAndView processSignup(@ModelAttribute("signup_user") UserEntity signupUser) {
        userService.addUser(signupUser);
        return new ModelAndView("redirect", "retitle", "You are successfully signed up!");
    }

    @ResponseStatus(value= HttpStatus.CONFLICT, reason="Data integrity violation")  // 409
    @ExceptionHandler(DataIntegrityViolationException.class)
    public void conflict() {
        //Nothing
    }

    @ExceptionHandler(SpringException.class)
    @ResponseStatus(value= HttpStatus.BAD_REQUEST, reason="Bad Request") //400
    public ModelAndView handleSpringException(SpringException ex) {
        return new ModelAndView("exception", "exception", ex);
    }

    @ExceptionHandler(Exception.class)
    public ModelAndView handleError(HttpServletRequest req, Exception ex) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("exception", ex);
        mav.addObject("url", req.getRequestURL());
        mav.setViewName("error");
        return mav;
    }
}
