package ir.example.web.controller;

import ir.example.web.model.PollEntity;
import ir.example.web.model.UserEntity;
import ir.example.web.service.PollService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@Controller
@SessionAttributes({"user"})
public class PollController {
    @Autowired
    private PollService pollService;

    @RequestMapping(value = "/vote/{pid}", method = RequestMethod.GET)
    protected ModelAndView showResult(@PathVariable("pid") int pid, @ModelAttribute("user") UserEntity userEntity) {
        PollEntity pollEntity = pollService.findPoll(pid);
        ModelAndView model = new ModelAndView();
        model.addObject("poll", pollEntity);
        if (pollService.alreadyChosen(pollEntity, userEntity) || (pollEntity.getStatus() == 1)) {
            model.addObject("vote_count", pollService.getPollVoteCount(pollEntity));
            model.addObject("poll_report", pollService.getPollReport(pollEntity));
            model.setViewName("result");
        } else {
            model.setViewName("vote");
        }
        return model;
    }

    //@RequestMapping(value = "/save/{pid:.+}", method = RequestMethod.POST)
    @RequestMapping(value = "/save/{pid}", method = RequestMethod.POST)
    protected ModelAndView saveVote(@PathVariable("pid") int pid, @RequestParam(value="choice", required=true) String choice, @ModelAttribute("user") UserEntity user) {
        PollEntity pollEntity = pollService.votePoll(pid, user, choice);
        ModelAndView model = new ModelAndView("result");
        model.addObject("vote_count", pollService.getPollVoteCount(pollEntity));
        model.addObject("poll_report", pollService.getPollReport(pollEntity));
        model.addObject("poll", pollEntity);
        return model;
    }

    @RequestMapping(value = "/new", method = RequestMethod.GET)
    protected String showNewPoll() {
        return "new";
    }

    @RequestMapping(value = "/new", method = RequestMethod.POST)
    protected String newPoll(@RequestParam(value="subject", required=true) String subject, @RequestParam(value="choices[]", required=true) String choices[], @ModelAttribute("user") UserEntity user) {
        pollService.addPoll(subject, choices, user.getId());
        return "redirect:/";
    }

    @RequestMapping(value = "/mark", method = RequestMethod.GET)
    protected String markPoll(@RequestParam(value="pid", required=true) int pid, @RequestParam(value="type", required=true) String type, @ModelAttribute("user") UserEntity user) {
        pollService.markPoll(pid, type, user.getId());
        return "redirect:/";
    }

}
