package ir.example.web.servlet;

import ir.example.web.model.User;
import ir.example.web.service.UserService;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Set;


@WebServlet(urlPatterns = "/user/list")
public class UsersServlet extends HttpServlet {
    private UserService userService;

    @Override
    public void init(ServletConfig config) throws ServletException {
        final ServletContext servletContext = config.getServletContext();

        userService = ((UserService) servletContext.getAttribute("user-service"));

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


        final Set<User> users = userService.findAll();

        req.setAttribute("users", users);

        req.getRequestDispatcher("/users.jsp").forward(req, resp);
    }
}
