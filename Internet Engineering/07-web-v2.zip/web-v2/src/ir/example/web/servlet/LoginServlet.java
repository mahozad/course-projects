package ir.example.web.servlet;

import ir.example.web.model.User;
import ir.example.web.service.UserService;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;


@WebServlet(urlPatterns = "/login")
public class LoginServlet extends HttpServlet {
    private UserService userService;

    @Override
    public void init(ServletConfig config) throws ServletException {
        final ServletContext servletContext = config.getServletContext();

        userService = ((UserService) servletContext.getAttribute("user-service"));
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        final HttpSession session = req.getSession();
        final User user = (User) session.getAttribute("user");

        if (user != null) {
            req.getRequestDispatcher("/user.jsp").forward(req, resp);
        } else {
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        final String username = req.getParameter("username");
        final String password = req.getParameter("password");

        final User user = userService.find(username, password);
        if (user == null) {
            resp.sendRedirect("/error.jsp");
        } else {
            final HttpSession session = req.getSession();
            session.setAttribute("user", user);

            Cookie cookie = new Cookie("user-id", String.valueOf(user.getId()));
            cookie.setMaxAge(100);
//            cookie.setDomain(".test.ir");
            resp.addCookie(cookie);

            req.getRequestDispatcher("/user.jsp").forward(req, resp);
        }
    }
}
