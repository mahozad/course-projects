package ir.example.web.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;


@WebServlet(urlPatterns = "/logout")
public class LogoutServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        final HttpSession session = req.getSession();
//        session.removeAttribute("user");

        session.invalidate();


        Cookie cookie = new Cookie("user-id", "");
        cookie.setMaxAge(0);
        resp.addCookie(cookie);

        resp.sendRedirect("/login");
    }

}
