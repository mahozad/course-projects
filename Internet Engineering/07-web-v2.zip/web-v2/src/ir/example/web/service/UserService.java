package ir.example.web.service;

import ir.example.web.model.User;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by mohammadchangani on 11/5/17.
 * internet-engineering
 */
public class UserService {

    private final Set<User> users;

    public UserService() {
        this.users = new HashSet<>();

        users.add(new User(1, "a", "a1"));
        users.add(new User(2, "b", "b1"));
        users.add(new User(3, "c", "c1"));
        users.add(new User(4, "d", "d1"));
        users.add(new User(5, "e", "e1"));
        users.add(new User(6, "f", "f1"));
    }

    public User find(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }

    public Set<User> findAll() {
        return users;
    }

    public User find(Integer id) {
        for (User user : users) {
            if (user.getId().equals(id)) {
                return user;
            }
        }
        return null;
    }
}
