package ir.example.web.filter;

import ir.example.web.model.User;
import ir.example.web.service.UserService;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter(urlPatterns = {"/user"})
public class Login2Filter implements Filter {
    private UserService userService;

    @Override
    public void init(FilterConfig config) throws ServletException {
        final ServletContext servletContext = config.getServletContext();

        userService = ((UserService) servletContext.getAttribute("user-service"));
    }


    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
        final HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        final HttpServletResponse httpServletResponse = (HttpServletResponse) response;

        final HttpSession session = httpServletRequest.getSession();
        User user = (User) session.getAttribute("user");

        if(user == null){
            final Cookie[] cookies = httpServletRequest.getCookies();
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("user-id")) {
                    final String userID = cookie.getValue();
                    user = userService.find(Integer.valueOf(userID));

                    if(user != null){
                        session.setAttribute("user", user);
                    }
                }
            }
        }

        if (user == null) {
            httpServletResponse.sendRedirect("/error.jsp");
        } else {
            filterChain.doFilter(request, response);
        }
    }

    @Override
    public void destroy() {

    }
}
