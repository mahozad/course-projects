package ir.example.httpserver.listener;

import ir.example.httpserver.model.GradeBook;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener()
public class AppListener implements ServletContextListener {
    public static GradeBook gb;

    public void contextInitialized(ServletContextEvent sce) {
        final ServletContext servletContext = sce.getServletContext();
        String warDeployPath = servletContext.getRealPath("/");
        gb = new GradeBook(warDeployPath + "input/grades.csv", warDeployPath + "input/weight.txt");
//        gb = new GradeBook(warDeployPath + "input/grades.xml", warDeployPath + "input/weight.txt");
        servletContext.setAttribute("gradebook", gb);
    }

    public void contextDestroyed(ServletContextEvent sce) {
    }
}
