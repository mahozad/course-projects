package ir.example.httpserver.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by sajjad on 10/12/2017.
 */

public class StudentInfo {
    private String name;
    private Map<String, Double> scores;

    public StudentInfo(String studentName) {
        name = studentName;
        scores = new HashMap<String, Double>();
    }

    public void setScores(String course, double score) {
        scores.put(course, score);
    }

    public String getName() {
        return name;
    }

    public double getAverage(Map<String, Integer> weights) {
        double totalScore = 0;
        int totalUnits = 0;
        for (String course : scores.keySet()) {
            totalScore += weights.get(course) * scores.get(course);
            totalUnits += weights.get(course);
        }
        return totalScore / totalUnits;
    }

    public int getFailCount() {
        int totalFails = 0;
        for (String course : scores.keySet()) {
            if (scores.get(course) < 10)
                totalFails++;
        }
        return totalFails;
    }
}
