package ir.example.httpserver.servlet;

/**
 * Created by sajjad on 3/29/2018.
 */

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import ir.example.httpserver.model.GradeBook;
import ir.example.httpserver.model.StudentInfo;

@WebServlet(urlPatterns = "/student")
public class StudentServlet extends HttpServlet {
    private GradeBook gb;

    @Override
    public void init(ServletConfig config) throws ServletException {
        final ServletContext servletContext = config.getServletContext();
        gb = ((GradeBook) servletContext.getAttribute("gradebook"));
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try (final PrintWriter writer = resp.getWriter()) {
            if (gb != null) {
                StudentInfo si = gb.getItem(req.getParameter("name"));
                if (si != null) {
                    DecimalFormat numberFormat = new DecimalFormat("#.00");
                    writer.println("<html>");
                    writer.println("<body>");
                    writer.println("<h1>" + si.getName() + "</h1>");
                    writer.println("<h2>" + "Average: " + numberFormat.format(si.getAverage(gb.getWeights())) + " (from 20) </h2>");
                    writer.println("<h2>" + "Failed: " + si.getFailCount() + " (course) </h2>");
                    writer.println("</body>");
                    writer.println("</html>");
                } else {
                    writer.println("<html><body><h1> Student Not Found! </h1></body></html>");
                }
            } else {
                writer.println("<html><body><h1> GradeBook Not Loaded! </h1></body></html>");
            }
            writer.close();
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    }
}
