package ir.example.httpserver.utils;

import ir.example.httpserver.model.StudentInfo;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by sajjad on 10/12/2017.
 */

public class CSVParser {
    public static List<StudentInfo> parse(String fileName) {
        ArrayList<StudentInfo> sia = new ArrayList<StudentInfo>();

        try(final BufferedReader bfReader = new BufferedReader(new FileReader(fileName))){
            String line;
            while ((line = bfReader.readLine()) != null) {
                line = line.replaceAll("\\s+", " ");
                String split[] = line.split(",");
                StudentInfo si = new StudentInfo(split[0]);
                for (int i = 1; i < (split.length - 1); i += 2)
                    si.setScores(split[i].trim(), Double.valueOf(split[i + 1]));
                sia.add(si);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return sia;
    }
}
