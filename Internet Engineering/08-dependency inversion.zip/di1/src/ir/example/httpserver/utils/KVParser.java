package ir.example.httpserver.utils;

import ir.example.httpserver.model.StudentInfo;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by sajjad on 10/12/2017.
 */

public class KVParser {
    public static Map<String, Integer> parse(String fileName) {
        Map<String, Integer> map = new HashMap<String, Integer>();

        try(final BufferedReader bfReader = new BufferedReader(new FileReader(fileName))){
            String line;
            while ((line = bfReader.readLine()) != null) {
                String split[] = line.split(":");
                map.put(split[0], Integer.valueOf(split[1].trim()));
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return map;
    }
}
