package ir.example.httpserver.utils;

import ir.example.httpserver.model.StudentInfo;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by sajjad on 10/12/2017.
 */

public class XMLParser {
    public static List<StudentInfo> parse(String fileName) {
        ArrayList<StudentInfo> sia = new ArrayList<StudentInfo>();

        File xmlFile = new File(fileName);
        if (!xmlFile.exists())
            return null;

        try {
            Document document = Jsoup.parse(xmlFile, "UTF-8");
            Elements stElements = document.select("student");
            for (Element stElement : stElements) {
                String name = stElement.select("name").first().text();
                StudentInfo si = new StudentInfo(name);
                Elements courseElements = stElement.select("course");
                for (Element courseElement : courseElements) {
                    String course = courseElement.select("name").text();
                    Double score = Double.valueOf(courseElement.select("score").text());
                    si.setScores(course, score);
                }
                sia.add(si);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return sia;
    }
}
