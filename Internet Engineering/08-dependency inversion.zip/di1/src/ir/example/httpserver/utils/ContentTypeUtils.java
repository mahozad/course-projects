package ir.example.httpserver.utils;

/**
 * Created by mohammadchangani on 10/4/17.
 * internet-engineering
 */

public class ContentTypeUtils {
    public static String findContentType(String path) {
        if (path.endsWith(".html") || path.endsWith(".htm")) {
            return "text/html";
        }
        if (path.endsWith(".png")) {
            return "image/png";
        }
        if (path.endsWith(".jpg") || path.endsWith(".jpeg")) {
            return "image/jpeg";
        }
        return "application/octet-stream";
    }
}
