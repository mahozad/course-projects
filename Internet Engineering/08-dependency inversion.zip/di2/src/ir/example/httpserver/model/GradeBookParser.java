package ir.example.httpserver.model;

import java.util.List;

/**
 * Created by sajjad on 10/12/2017.
 */

public interface GradeBookParser {
    public List<StudentInfo> parse();
}
