package ir.example.httpserver.model;

import ir.example.httpserver.utils.KVParser;
import java.util.List;
import java.util.Map;

/**
 * Created by sajjad on 10/12/2017.
 */

public class GradeBook {
    private List<StudentInfo> students;
    private Map<String, Integer> weights;

    public GradeBook(GradeBookParser parser, String weightFileName) {
        students = parser.parse();
        weights = KVParser.parse(weightFileName);
    }

    public StudentInfo getItem(String name) {
        for (StudentInfo si : students) {
            if (si.getName().equals(name))
                return si;
        }
        return null;
    }

    public Map<String, Integer> getWeights() {
        return weights;
    }

    public double percentPassed() {
        int passedCount = 0;
        for (StudentInfo si : students) {
            passedCount += (si.getAverage(weights) >= 12 ? 1 : 0);
        }
        return passedCount * 100.0F / students.size();
    }
}

