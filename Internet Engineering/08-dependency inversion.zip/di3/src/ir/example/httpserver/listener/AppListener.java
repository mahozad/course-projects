package ir.example.httpserver.listener;

import ir.example.httpserver.model.GradeBook;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener()
public class AppListener implements ServletContextListener {
    public static GradeBook gb;
    public static String warDeployPath;

    public void contextInitialized(ServletContextEvent sce) {
        final ServletContext servletContext = sce.getServletContext();
        warDeployPath = servletContext.getRealPath("/");
        ApplicationContext ctx = new FileSystemXmlApplicationContext(warDeployPath + "config.xml");
        gb = (GradeBook) ctx.getBean("gradebook");
        servletContext.setAttribute("gradebook", gb);
    }

    public void contextDestroyed(ServletContextEvent sce) {
    }
}
