package ir.example.httpserver.model;

import ir.example.httpserver.listener.AppListener;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by sajjad on 10/12/2017.
 */

public class CSVGradeBookParser implements GradeBookParser {
    private String filename;

    public CSVGradeBookParser(String filename) {
        this.filename = AppListener.warDeployPath + filename;
    }

    public List<StudentInfo> parse() {
        ArrayList<StudentInfo> sia = new ArrayList<StudentInfo>();

        try(final BufferedReader bfReader = new BufferedReader(new FileReader(filename))){
            String line;
            while ((line = bfReader.readLine()) != null) {
                line = line.replaceAll("\\s+", " ");
                String split[] = line.split(",");
                StudentInfo si = new StudentInfo(split[0]);
                for (int i = 1; i < (split.length - 1); i += 2)
                    si.setScores(split[i].trim(), Double.valueOf(split[i + 1]));
                sia.add(si);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return sia;
    }
}
