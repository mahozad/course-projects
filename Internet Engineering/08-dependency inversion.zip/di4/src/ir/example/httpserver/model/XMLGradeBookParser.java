package ir.example.httpserver.model;

import ir.example.httpserver.listener.AppListener;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by sajjad on 10/12/2017.
 */

public class XMLGradeBookParser implements GradeBookParser {
    private String filename;

    public void setFilename(String filename) {
        this.filename = AppListener.warDeployPath + filename;
    }

    public List<StudentInfo> parse() {
        ArrayList<StudentInfo> sia = new ArrayList<StudentInfo>();

        File xmlFile = new File(filename);
        if (!xmlFile.exists())
            return null;

        try {
            Document document = Jsoup.parse(xmlFile, "UTF-8");
            Elements stElements = document.select("student");
            for (Element stElement : stElements) {
                String name = stElement.select("name").first().text();
                StudentInfo si = new StudentInfo(name);
                Elements courseElements = stElement.select("course");
                for (Element courseElement : courseElements) {
                    String course = courseElement.select("name").text();
                    Double score = Double.valueOf(courseElement.select("score").text());
                    si.setScores(course, score);
                }
                sia.add(si);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return sia;
    }
}
