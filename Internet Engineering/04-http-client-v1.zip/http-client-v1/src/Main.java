import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.*;

/**
 * Created by mohammadchangani on 10/10/17.
 * internet-engineering
 */
public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println(get("http://google.com"));
    }

    public static String get(String url) throws Exception {
        final HttpClient httpClient = new DefaultHttpClient();

        final HttpGet httpget = new HttpGet(url);

        final HttpResponse response = httpClient.execute(httpget);
        final int statusCode = response.getStatusLine().getStatusCode();

        if (statusCode == 200) {
            final HttpEntity entity = response.getEntity();
            return EntityUtils.toString(entity);
        } else {
            throw new IOException("Unexpected response status: " + statusCode);
        }

    }

    private static void head(String url) throws Exception {
        final HttpClient httpClient = new DefaultHttpClient();

        final HttpHead httpHead = new HttpHead(url);
        httpClient.execute(httpHead);

    }


    public static String post(String url) throws Exception {
        final HttpClient httpClient = new DefaultHttpClient();

        final HttpPost httpPost = new HttpPost(url);

        httpPost.setEntity(new StringEntity("text"));
//            httpPost.setEntity(new FileEntity(new File("/root/test.txt")));


        final HttpResponse response = httpClient.execute(httpPost);
        final int statusCode = response.getStatusLine().getStatusCode();

        if (statusCode == 200) {
            final HttpEntity entity = response.getEntity();
            return EntityUtils.toString(entity);
        } else {
            throw new IOException("Unexpected response status: " + statusCode);
        }

    }

    public static String post2(String url) throws Exception {
        final HttpClient httpClient = new DefaultHttpClient();

        final HttpPost httpPost = new HttpPost(url);

        final FileBody fileBody = new FileBody(new File("/root/test.txt"), ContentType.DEFAULT_BINARY);
        final StringBody stringBody1 = new StringBody("Message 1", ContentType.DEFAULT_TEXT);
        final StringBody stringBody2 = new StringBody("Message 2", ContentType.DEFAULT_TEXT);

        final MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        builder.addPart("file1", fileBody);
        builder.addPart("text1", stringBody1);
        builder.addPart("text2", stringBody2);

        httpPost.setEntity(builder.build());

        final HttpResponse response = httpClient.execute(httpPost);
        final int statusCode = response.getStatusLine().getStatusCode();

        if (statusCode == 200) {
            final HttpEntity entity = response.getEntity();
            return EntityUtils.toString(entity);
        } else {
            throw new IOException("Unexpected response status: " + statusCode);
        }

    }
}
