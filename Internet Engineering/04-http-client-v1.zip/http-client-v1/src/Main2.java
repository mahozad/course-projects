import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.Date;

/**
 * Created by mohammadchangani on 10/10/17.
 * internet-engineering
 */
public class Main2 {
    public static void main(String[] args) throws Exception {
        System.out.println(get("http://google.com"));
    }


    public static String get(String url) throws Exception {
        final HttpClient httpClient = new DefaultHttpClient();

        //set timeout
        HttpParams httpParams = httpClient.getParams();
        HttpConnectionParams.setConnectionTimeout(httpParams, 1 * 1000);
        HttpConnectionParams.setSoTimeout(httpParams, 10 * 1000);


        final HttpContext httpContext = new BasicHttpContext();

        //create cookie
        final CookieStore cookieStore = new BasicCookieStore();
        final BasicClientCookie cookie = new BasicClientCookie("JSESSIONID", "1231");
        cookie.setPath("/");
        cookieStore.addCookie(cookie);

        final BasicClientCookie cookie2 = new BasicClientCookie("asf", "1231");
        cookie2.setPath("/");
        cookie2.setExpiryDate(new Date());
        cookieStore.addCookie(cookie2);

        httpContext.setAttribute(HttpClientContext.COOKIE_STORE, cookieStore);


        HttpGet httpget = new HttpGet(url);
        httpget.setHeader("User-Agent", "my-agent");

//        httpget.setHeader("Cookie", "JSESSIONID=1234&abc=ghj");


        final HttpResponse response = httpClient.execute(httpget, httpContext);
        final int statusCode = response.getStatusLine().getStatusCode();

        if (statusCode == 200) {
            final HttpEntity entity = response.getEntity();
            return EntityUtils.toString(entity);
        } else {
            throw new IOException("Unexpected response status: " + statusCode);
        }
    }
}
