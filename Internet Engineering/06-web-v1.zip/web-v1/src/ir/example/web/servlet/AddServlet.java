package ir.example.web.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;


@WebServlet(urlPatterns = "/add")
public class AddServlet extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            final String n1 = req.getParameter("n1");
            final String n2 = req.getParameter("n2");

            final Integer number1 = Integer.valueOf(n1);
            final Integer number2 = Integer.valueOf(n2);

            final Integer number3 = number1 + number2;


            req.setAttribute("result", number3);
            req.setAttribute("date", new Date());

            req.getRequestDispatcher("/index2.jsp").forward(req, resp);
//        final PrintWriter writer = resp.getWriter();
//        writer.println("Hello");
//        writer.close();

//            req.getRequestDispatcher("/index.jsp").include(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
