package ir.example.web.servlet;

import ir.example.web.model.User;
import ir.example.web.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet(urlPatterns = "/user")
public class UserServlet extends HttpServlet {
    private UserService userService;

    @Override
    public void init() throws ServletException {
        userService = new UserService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        final Integer id = Integer.valueOf(req.getParameter("id"));

        final User user = userService.find(id);

        req.setAttribute("user", user);

        req.getRequestDispatcher("/user.jsp").forward(req, resp);

    }
}
