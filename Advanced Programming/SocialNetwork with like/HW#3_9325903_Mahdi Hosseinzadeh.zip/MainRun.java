
public class MainRun {

    public static void main(String[] args) {
        SocialMain program = new SocialMain();//an instance variable of class SocialMain
        program.social();
    }
}
